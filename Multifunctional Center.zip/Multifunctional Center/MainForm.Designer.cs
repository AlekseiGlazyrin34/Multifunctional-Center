﻿
namespace Multifunctional_Center
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.Reg_la = new System.Windows.Forms.Label();
            this.Log_btn = new System.Windows.Forms.Button();
            this.Pass_txt = new System.Windows.Forms.TextBox();
            this.Lg_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Reg_la
            // 
            this.Reg_la.AutoSize = true;
            this.Reg_la.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Reg_la.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Reg_la.Location = new System.Drawing.Point(230, 384);
            this.Reg_la.Name = "Reg_la";
            this.Reg_la.Size = new System.Drawing.Size(154, 19);
            this.Reg_la.TabIndex = 9;
            this.Reg_la.Text = "Зарегистрироваться?";
            this.Reg_la.Click += new System.EventHandler(this.Reg_la_Click);
            // 
            // Log_btn
            // 
            this.Log_btn.BackColor = System.Drawing.Color.Tomato;
            this.Log_btn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Log_btn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Log_btn.Location = new System.Drawing.Point(207, 309);
            this.Log_btn.Name = "Log_btn";
            this.Log_btn.Size = new System.Drawing.Size(197, 72);
            this.Log_btn.TabIndex = 8;
            this.Log_btn.Text = "ВОЙТИ";
            this.Log_btn.UseVisualStyleBackColor = false;
            this.Log_btn.Click += new System.EventHandler(this.Log_btn_Click);
            // 
            // Pass_txt
            // 
            this.Pass_txt.Location = new System.Drawing.Point(207, 274);
            this.Pass_txt.Name = "Pass_txt";
            this.Pass_txt.Size = new System.Drawing.Size(197, 20);
            this.Pass_txt.TabIndex = 7;
            // 
            // Lg_txt
            // 
            this.Lg_txt.Location = new System.Drawing.Point(207, 234);
            this.Lg_txt.Name = "Lg_txt";
            this.Lg_txt.Size = new System.Drawing.Size(197, 20);
            this.Lg_txt.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(68, 230);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 23);
            this.label2.TabIndex = 10;
            this.label2.Text = "Email / Телефон";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(131, 271);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Пароль";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(207, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(197, 188);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(596, 456);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Reg_la);
            this.Controls.Add(this.Log_btn);
            this.Controls.Add(this.Pass_txt);
            this.Controls.Add(this.Lg_txt);
            this.Name = "MainForm";
            this.Text = "Вход в систему";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Reg_la;
        private System.Windows.Forms.Button Log_btn;
        private System.Windows.Forms.TextBox Pass_txt;
        private System.Windows.Forms.TextBox Lg_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

