﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multifunctional_Center
{
    static class DataBank
    {
        public static int PassportSerie;
        public static int PassportNumber;
        public static string FirstName;
        public static string LastName;
        public static string Surname;
        public static string Email;
        public static string Password;
        public static string PhoneNumber;
        public static string Address;
        public static int Access;
    }
}
