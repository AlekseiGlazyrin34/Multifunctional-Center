﻿
namespace Multifunctional_Center
{
    partial class Kabinet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kabinet));
            this.LastName_lbl = new System.Windows.Forms.Label();
            this.FirstName_lbl = new System.Windows.Forms.Label();
            this.Surname_lbl = new System.Windows.Forms.Label();
            this.PhoneNumber_lbl = new System.Windows.Forms.Label();
            this.Email_lbl = new System.Windows.Forms.Label();
            this.Address_lbl = new System.Windows.Forms.Label();
            this.SerieNum_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LeftArrow_btn = new System.Windows.Forms.PictureBox();
            this.Logout_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // LastName_lbl
            // 
            this.LastName_lbl.AutoSize = true;
            this.LastName_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LastName_lbl.Location = new System.Drawing.Point(281, 71);
            this.LastName_lbl.Name = "LastName_lbl";
            this.LastName_lbl.Size = new System.Drawing.Size(59, 15);
            this.LastName_lbl.TabIndex = 1;
            this.LastName_lbl.Text = "Фамилия";
            // 
            // FirstName_lbl
            // 
            this.FirstName_lbl.AutoSize = true;
            this.FirstName_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FirstName_lbl.Location = new System.Drawing.Point(281, 96);
            this.FirstName_lbl.Name = "FirstName_lbl";
            this.FirstName_lbl.Size = new System.Drawing.Size(30, 15);
            this.FirstName_lbl.TabIndex = 2;
            this.FirstName_lbl.Text = "Имя";
            // 
            // Surname_lbl
            // 
            this.Surname_lbl.AutoSize = true;
            this.Surname_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Surname_lbl.Location = new System.Drawing.Point(281, 120);
            this.Surname_lbl.Name = "Surname_lbl";
            this.Surname_lbl.Size = new System.Drawing.Size(57, 15);
            this.Surname_lbl.TabIndex = 3;
            this.Surname_lbl.Text = "Отчество";
            // 
            // PhoneNumber_lbl
            // 
            this.PhoneNumber_lbl.AutoSize = true;
            this.PhoneNumber_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneNumber_lbl.Location = new System.Drawing.Point(281, 144);
            this.PhoneNumber_lbl.Name = "PhoneNumber_lbl";
            this.PhoneNumber_lbl.Size = new System.Drawing.Size(100, 15);
            this.PhoneNumber_lbl.TabIndex = 4;
            this.PhoneNumber_lbl.Text = "Номер телефона";
            // 
            // Email_lbl
            // 
            this.Email_lbl.AutoSize = true;
            this.Email_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Email_lbl.Location = new System.Drawing.Point(281, 169);
            this.Email_lbl.Name = "Email_lbl";
            this.Email_lbl.Size = new System.Drawing.Size(38, 15);
            this.Email_lbl.TabIndex = 5;
            this.Email_lbl.Text = "Email";
            // 
            // Address_lbl
            // 
            this.Address_lbl.AutoSize = true;
            this.Address_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Address_lbl.Location = new System.Drawing.Point(281, 192);
            this.Address_lbl.Name = "Address_lbl";
            this.Address_lbl.Size = new System.Drawing.Size(40, 15);
            this.Address_lbl.TabIndex = 6;
            this.Address_lbl.Text = "Адрес";
            // 
            // SerieNum_lbl
            // 
            this.SerieNum_lbl.AutoSize = true;
            this.SerieNum_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SerieNum_lbl.Location = new System.Drawing.Point(281, 215);
            this.SerieNum_lbl.Name = "SerieNum_lbl";
            this.SerieNum_lbl.Size = new System.Drawing.Size(145, 15);
            this.SerieNum_lbl.TabIndex = 7;
            this.SerieNum_lbl.Text = "Серия и номер паспорта";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(336, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 8;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView1.Enabled = false;
            this.dataGridView1.Location = new System.Drawing.Point(90, 335);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(590, 135);
            this.dataGridView1.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Tomato;
            this.label5.Location = new System.Drawing.Point(241, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(259, 33);
            this.label5.TabIndex = 10;
            this.label5.Text = "Личная информация";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Tomato;
            this.label1.Location = new System.Drawing.Point(229, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 33);
            this.label1.TabIndex = 11;
            this.label1.Text = "Мои записи на приемы";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Адрес";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Дата";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Время";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Услуга";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 250;
            // 
            // LeftArrow_btn
            // 
            this.LeftArrow_btn.Image = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.Image")));
            this.LeftArrow_btn.InitialImage = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.InitialImage")));
            this.LeftArrow_btn.Location = new System.Drawing.Point(3, 3);
            this.LeftArrow_btn.Name = "LeftArrow_btn";
            this.LeftArrow_btn.Size = new System.Drawing.Size(22, 22);
            this.LeftArrow_btn.TabIndex = 12;
            this.LeftArrow_btn.TabStop = false;
            this.LeftArrow_btn.Click += new System.EventHandler(this.LeftArrow_btn_Click);
            // 
            // Logout_btn
            // 
            this.Logout_btn.BackColor = System.Drawing.Color.Red;
            this.Logout_btn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Logout_btn.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Logout_btn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Logout_btn.Location = new System.Drawing.Point(682, 3);
            this.Logout_btn.Name = "Logout_btn";
            this.Logout_btn.Size = new System.Drawing.Size(75, 41);
            this.Logout_btn.TabIndex = 13;
            this.Logout_btn.Text = "ВЫЙТИ ИЗ СИСТЕМЫ";
            this.Logout_btn.UseVisualStyleBackColor = false;
            this.Logout_btn.Click += new System.EventHandler(this.Logout_btn_Click);
            // 
            // Kabinet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(760, 535);
            this.Controls.Add(this.Logout_btn);
            this.Controls.Add(this.LeftArrow_btn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SerieNum_lbl);
            this.Controls.Add(this.Address_lbl);
            this.Controls.Add(this.Email_lbl);
            this.Controls.Add(this.PhoneNumber_lbl);
            this.Controls.Add(this.Surname_lbl);
            this.Controls.Add(this.FirstName_lbl);
            this.Controls.Add(this.LastName_lbl);
            this.Name = "Kabinet";
            this.Text = "Личный кабинет";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LastName_lbl;
        private System.Windows.Forms.Label FirstName_lbl;
        private System.Windows.Forms.Label Surname_lbl;
        private System.Windows.Forms.Label PhoneNumber_lbl;
        private System.Windows.Forms.Label Email_lbl;
        private System.Windows.Forms.Label Address_lbl;
        private System.Windows.Forms.Label SerieNum_lbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox LeftArrow_btn;
        private System.Windows.Forms.Button Logout_btn;
    }
}