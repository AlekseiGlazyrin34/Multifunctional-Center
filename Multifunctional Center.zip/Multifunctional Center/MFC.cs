﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Multifunctional_Center
{
    public partial class MFC : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-H07OG6B; Initial Catalog=Multifunctional Center; Integrated Security=True");
        public MFC()
        {
            InitializeComponent();
        }

        
        private void Zapis_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Zapis ZapisForm = new Zapis();
            ZapisForm.Show();
        }

        

        private void MFC_Load(object sender, EventArgs e)
        {
            if (User.Access == 1) MFCAdmin_btn.Visible = true;
        }

        private void MFCAdmin_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminForm Adminform = new AdminForm();
            Adminform.Show();
        }

        private void Kab_lbl_Click(object sender, EventArgs e)
        {
            this.Hide();
            Kabinet Kab = new Kabinet();
            Kab.Show();
        }

        
    }
}
