﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Multifunctional_Center
{
    
    
    public partial class MainForm : System.Windows.Forms.Form
    {
        
        public MainForm()
        {
            InitializeComponent();
        }



        private void Log_btn_Click(object sender, EventArgs e)
        {
            var Email = Lg_txt.Text;
            var Password = Pass_txt.Text;
            int Check = 0;
            string queryString2 = string.Format("SELECT 1,Passport_Serie,Passport_Number, First_Name,Last_Name,Surname,Email,Password,Phone_Number,Address,Access FROM [Registered users] WHERE (Email='" + Email + "' OR Phone_Number='" + Email + "')AND Password='" + Password + "';");

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-H07OG6B; Initial Catalog=Multifunctional Center; Integrated Security=True"))
            {
                connection.Open();
                using (SqlCommand cmd2 = new SqlCommand(queryString2, connection))
                using (SqlDataReader dataReader = cmd2.ExecuteReader())
                {
                    try
                    {
                        while (dataReader.Read())
                        {
                            if (!dataReader.IsDBNull(0) && !dataReader.IsDBNull(1) && !dataReader.IsDBNull(2) && !dataReader.IsDBNull(3) && !dataReader.IsDBNull(4) && !dataReader.IsDBNull(5) && !dataReader.IsDBNull(6) && !dataReader.IsDBNull(7) && !dataReader.IsDBNull(8) && !dataReader.IsDBNull(9) && !dataReader.IsDBNull(10))
                            {
                                Check = dataReader.GetInt32(0);
                                if (Check == 1)
                                {
                                    User.PassportSerie = dataReader.GetInt32(1);
                                    User.PassportNumber = dataReader.GetInt32(2);
                                    User.FirstName = dataReader.GetString(3);
                                    User.LastName = dataReader.GetString(4);
                                    User.Surname = dataReader.GetString(5);
                                    User.Email = dataReader.GetString(6);
                                    User.Password = dataReader.GetString(7);
                                    User.PhoneNumber= dataReader.GetString(8);
                                    User.Address = dataReader.GetString(9);
                                    User.Access= dataReader.GetInt32(10);
                                    this.Hide();
                                    MFC MFCForm = new MFC();
                                    MFCForm.Show();                                    
                                }
                                else MessageBox.Show("Неверный логин или пароль");

                            }
                            



                        }
                    }
                    catch
                    {
                    }
                }
            }
           
        }

        private void Reg_la_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegForm RegForm = new RegForm();
            RegForm.Show();
           
        }
    }
    static class User
    {

        public static int PassportSerie;
        public static int PassportNumber;
        public static string FirstName;
        public static string LastName;
        public static string Surname;
        public static string Email;
        public static string Password;
        public static string PhoneNumber;
        public static string Address;
        public static int Access;

    }
}
