﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Multifunctional_Center
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }
        void load_data()
        {
            SqlDataAdapter sqlData1 = new SqlDataAdapter("SELECT*FROM [Registered users]", connection);
            DataTable data1 = new DataTable();
            sqlData1.Fill(data1);
            dataGridView1.DataSource = data1;

            SqlDataAdapter sqlData2 = new SqlDataAdapter("SELECT*FROM [Appointment list]", connection);
            DataTable data2 = new DataTable();
            sqlData2.Fill(data2);
            dataGridView2.DataSource = data2;

            SqlDataAdapter sqlData3 = new SqlDataAdapter("SELECT*FROM [Employees]", connection);
            DataTable data3 = new DataTable();
            sqlData3.Fill(data3);
            dataGridView3.DataSource = data3;

            SqlDataAdapter sqlData4 = new SqlDataAdapter("SELECT*FROM [Multifunctional Center]", connection);
            DataTable data4 = new DataTable();
            sqlData4.Fill(data4);
            dataGridView4.DataSource = data4;

            SqlDataAdapter sqlData5 = new SqlDataAdapter("SELECT*FROM [Jobs]", connection);
            DataTable data5 = new DataTable();
            sqlData5.Fill(data5);
            dataGridView5.DataSource = data5;

            SqlDataAdapter sqlData6 = new SqlDataAdapter("SELECT*FROM [Services List]", connection);
            DataTable data6 = new DataTable();
            sqlData6.Fill(data6);
            dataGridView6.DataSource = data6;

        }

        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-H07OG6B; Initial Catalog=Multifunctional Center; Integrated Security=True");
        private void AdminForm_Load(object sender, EventArgs e)
        {
            connection.Open();
            load_data();

        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("INSERT INTO [Registered users] (Passport_Serie,Passport_Number,First_Name,Last_Name,Surname,Email,Password,Phone_Number,Address,Access)" +
                " VALUES('" + PassSerie.Text + " ',' " + PassNumber.Text + "' , '" + FirstName.Text + "' , '" + LastName.Text + " ', '" + Surname.Text + " ', '" + Email.Text + " ', '" + Password.Text + " ', '" + PhoneNumber.Text + " ', '" + Address.Text + " ', '" + Access.Text + " ')", connection);
            connection.Open();
            command.ExecuteNonQuery();
            clear_fun();
            MessageBox.Show("Сохранено");

        }

        private void Update_btn_Click(object sender, EventArgs e)
        { 
            if (PassSerie.Text == "" || PassNumber.Text =="" || FirstName.Text =="" ||  LastName.Text=="" || Surname.Text=="" || Email.Text=="" || Password.Text == "" || PhoneNumber.Text == "" || Address.Text == "" || Access.Text == "")
            {
                MessageBox.Show("Заполните все поля");
            }
            else
            {
                SqlCommand command = new SqlCommand("UPDATE [Registered users] SET Passport_Serie='" + PassSerie.Text + "', Passport_Number='" + PassNumber.Text + "', First_Name='" + FirstName.Text + "', Last_Name='" + LastName.Text + "', Surname='" + Surname.Text + "', Email='" + Email.Text + "', Password='" + Password.Text + "', Phone_Number='" + PhoneNumber.Text + "', Address='" + Address.Text + "', Access='" + Access.Text + "' where Passport_Serie='" + PassSerie.Text + "' AND Passport_Number='" + PassNumber.Text + "'", connection);
                command.ExecuteNonQuery();
                load_data();
                clear_fun();
                MessageBox.Show("Данные обновлены");
            }
        }

        private void Delete_btn_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("DELETE FROM [Registered users] WHERE Passport_Serie='" + PassSerie.Text + "' AND Passport_Number='" + PassNumber.Text + "'", connection);
            command.ExecuteNonQuery();
            load_data();
            clear_fun();
            MessageBox.Show("Deleted");

        }
        void clear_fun()
        {
            PassSerie.Text = "";
            PassNumber.Text = "";
            FirstName.Text = "";
            LastName.Text = "";
            Surname.Text = "";
            Email.Text = "";
            Password.Text = "";
            PhoneNumber.Text = "";
            Address.Text = "";
            Access.Text = "";

        }

        private void Clear_btn_Click(object sender, EventArgs e)
        {
            clear_fun();
        }




        private void Save_btn2_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("INSERT INTO [Appointment list] (UserPassportSerie,UserPassportNumber,Employee_Id,Service_Provided,A_Date,A_Time)" +
                " VALUES(' " + UserPassportSerie.Text + "' , '" + UserPassportNumber.Text + "' , '" + Employee_Id.Text + " ', '" + Service_Provided.Text + " ', '" + A_Date.Text + " ', '" + A_Time.Text + " ')", connection);
            connection.Open();
            command.ExecuteNonQuery();
            clear_fun();
            MessageBox.Show("Сохранено");

        }

        private void Update_btn2_Click(object sender, EventArgs e)
        {
            if (Appointment_Id.Text == "" || UserPassportSerie.Text == "" || UserPassportNumber.Text == "" || Employee_Id.Text == "" || Service_Provided.Text == "" || A_Date.Text == "" || A_Time.Text == "")
            {
                MessageBox.Show("Заполните все поля");
            }
            else
            {
                SqlCommand command = new SqlCommand("UPDATE [Appointment list] SET  UserPassportSerie='" + UserPassportSerie.Text + "', UserPassportNumber='" + UserPassportNumber.Text + "', Employee_Id='" + Employee_Id.Text + "', Service_Provided='" + Service_Provided.Text + "',A_Date='" + A_Date.Text + "', A_Time='" + A_Time.Text + "' WHERE Appointment_Id='" + Appointment_Id.Text + "'", connection);
                command.ExecuteNonQuery();
                load_data();
                clear_fun();
                MessageBox.Show("Данные обновлены");
            }
        }

        private void Delete_btn2_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("DELETE FROM [Appointment list] WHERE (UserPassportSerie='" + UserPassportSerie.Text + "' AND UserPassportNumber='" + UserPassportNumber.Text + "') OR Appointment_Id='" + Appointment_Id.Text + "'", connection);
            command.ExecuteNonQuery();
            load_data();
            clear_fun();
            MessageBox.Show("Удалено");

        }
        void clear_fun2()
        {
            Appointment_Id.Text = "";
            UserPassportSerie.Text = "";
            UserPassportNumber.Text = "";
            Employee_Id.Text = "";
            Service_Provided.Text = "";
            A_Date.Text = "";
            A_Time.Text = "";

        }

        private void Clear_btn2_Click(object sender, EventArgs e)
        {
            clear_fun2();
        }

        private void LeftArrow_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MFC Mfc = new MFC();
            Mfc.Show();
        }
    }
}
