﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Multifunctional_Center
{
    public partial class Kabinet : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-H07OG6B; Initial Catalog=Multifunctional Center; Integrated Security=True");
        public Kabinet()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            connection.Open();
            string query = "SELECT Center_Address,A_Date,A_Time,Service_Name FROM [Appointment List], Employees,[Multifunctional Center], [Services List]  " +
                "WHERE[Appointment List].Employee_Id = Employees.Employee_Id AND Employees.Center_Id = [Multifunctional Center].Center_Id AND [Appointment List].Service_Provided= [Services List].Service_Id AND UserPassportSerie ='" + User.PassportSerie + "' AND UserPassportNumber= '" + User.PassportNumber + "'; ";

            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();

            while (reader.Read())
            {
                data.Add(new string[4]);

                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
            }
            reader.Close();
            connection.Close();

            foreach (string[] s in data)
            {
                dataGridView1.Rows.Add(s);
            }

            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            LastName_lbl.Text = "Фамилия: " + User.LastName;
            FirstName_lbl.Text = "Имя: " + User.FirstName;
            Surname_lbl.Text = "Отчество: " + User.Surname;
            PhoneNumber_lbl.Text = "Номер телефона: " + User.PhoneNumber;
            Email_lbl.Text = "Электронная почта: " + User.Email;
            Address_lbl.Text = "Адресс: " + User.Address;
            SerieNum_lbl.Text = "Серия и номер паспорта: " + User.PassportSerie+" "+ User.PassportNumber;


        }

        private void LeftArrow_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MFC Mfc = new MFC();
            Mfc.Show();

        }

        private void Logout_btn_Click(object sender, EventArgs e)
        {
            User.PassportSerie = 0;
            User.PassportNumber = 0;
            User.FirstName = "";
            User.LastName = "";
            User.Surname = "";
            User.Email = "";
            User.Password = "";
            User.PhoneNumber = "";
            User.Address = "";
            User.Access = 0;
            this.Hide();
            MainForm Mainform = new MainForm();
            Mainform.Show();
        }
    }
}
