﻿
namespace Multifunctional_Center
{
    partial class RegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegForm));
            this.label1 = new System.Windows.Forms.Label();
            this.Name_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LastName_txt = new System.Windows.Forms.TextBox();
            this.Surname_txt = new System.Windows.Forms.TextBox();
            this.PSerie_txt = new System.Windows.Forms.TextBox();
            this.PNumber_txt = new System.Windows.Forms.TextBox();
            this.Phone_txt = new System.Windows.Forms.TextBox();
            this.Address_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.Email_txt = new System.Windows.Forms.TextBox();
            this.Reg_btn = new System.Windows.Forms.Button();
            this.LeftArrow_btn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(122, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Регистрация";
            // 
            // Name_txt
            // 
            this.Name_txt.Location = new System.Drawing.Point(174, 98);
            this.Name_txt.Name = "Name_txt";
            this.Name_txt.Size = new System.Drawing.Size(115, 20);
            this.Name_txt.TabIndex = 1;
            this.Name_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Name_txt_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(124, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Имя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(84, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "Фамилия";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(86, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 23);
            this.label4.TabIndex = 4;
            this.label4.Text = "Отчество";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(33, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 23);
            this.label5.TabIndex = 5;
            this.label5.Text = "Серия паспорта";
            // 
            // LastName_txt
            // 
            this.LastName_txt.Location = new System.Drawing.Point(174, 72);
            this.LastName_txt.Name = "LastName_txt";
            this.LastName_txt.Size = new System.Drawing.Size(115, 20);
            this.LastName_txt.TabIndex = 6;
            this.LastName_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LastName_txt_KeyPress);
            // 
            // Surname_txt
            // 
            this.Surname_txt.Location = new System.Drawing.Point(174, 124);
            this.Surname_txt.Name = "Surname_txt";
            this.Surname_txt.Size = new System.Drawing.Size(115, 20);
            this.Surname_txt.TabIndex = 7;
            this.Surname_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Surname_txt_KeyPress);
            // 
            // PSerie_txt
            // 
            this.PSerie_txt.Location = new System.Drawing.Point(174, 205);
            this.PSerie_txt.Name = "PSerie_txt";
            this.PSerie_txt.Size = new System.Drawing.Size(115, 20);
            this.PSerie_txt.TabIndex = 8;
            this.PSerie_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PSerie_txt_KeyPress);
            // 
            // PNumber_txt
            // 
            this.PNumber_txt.Location = new System.Drawing.Point(174, 232);
            this.PNumber_txt.Name = "PNumber_txt";
            this.PNumber_txt.Size = new System.Drawing.Size(115, 20);
            this.PNumber_txt.TabIndex = 9;
            // 
            // Phone_txt
            // 
            this.Phone_txt.Location = new System.Drawing.Point(174, 151);
            this.Phone_txt.Name = "Phone_txt";
            this.Phone_txt.Size = new System.Drawing.Size(115, 20);
            this.Phone_txt.TabIndex = 10;
            this.Phone_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Phone_txt_KeyPress);
            // 
            // Address_txt
            // 
            this.Address_txt.Location = new System.Drawing.Point(174, 178);
            this.Address_txt.Name = "Address_txt";
            this.Address_txt.Size = new System.Drawing.Size(115, 20);
            this.Address_txt.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(27, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 23);
            this.label6.TabIndex = 12;
            this.label6.Text = "Номер паспорта";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(24, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 23);
            this.label7.TabIndex = 13;
            this.label7.Text = "Номер телефона";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(109, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 23);
            this.label8.TabIndex = 14;
            this.label8.Text = "Адрес";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(13, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(155, 23);
            this.label9.TabIndex = 15;
            this.label9.Text = "Элекронная почта";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(98, 283);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 23);
            this.label10.TabIndex = 16;
            this.label10.Text = "Пароль";
            // 
            // Password_txt
            // 
            this.Password_txt.Location = new System.Drawing.Point(174, 286);
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.Size = new System.Drawing.Size(115, 20);
            this.Password_txt.TabIndex = 18;
            // 
            // Email_txt
            // 
            this.Email_txt.Location = new System.Drawing.Point(174, 259);
            this.Email_txt.Name = "Email_txt";
            this.Email_txt.Size = new System.Drawing.Size(115, 20);
            this.Email_txt.TabIndex = 19;
            // 
            // Reg_btn
            // 
            this.Reg_btn.BackColor = System.Drawing.Color.Tomato;
            this.Reg_btn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Reg_btn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Reg_btn.Location = new System.Drawing.Point(90, 324);
            this.Reg_btn.Name = "Reg_btn";
            this.Reg_btn.Size = new System.Drawing.Size(225, 59);
            this.Reg_btn.TabIndex = 22;
            this.Reg_btn.Text = "Зарегистрироваться";
            this.Reg_btn.UseVisualStyleBackColor = false;
            this.Reg_btn.Click += new System.EventHandler(this.Reg_btn_Click);
            // 
            // LeftArrow_btn
            // 
            this.LeftArrow_btn.Image = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.Image")));
            this.LeftArrow_btn.InitialImage = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.InitialImage")));
            this.LeftArrow_btn.Location = new System.Drawing.Point(3, 2);
            this.LeftArrow_btn.Name = "LeftArrow_btn";
            this.LeftArrow_btn.Size = new System.Drawing.Size(22, 22);
            this.LeftArrow_btn.TabIndex = 23;
            this.LeftArrow_btn.TabStop = false;
            this.LeftArrow_btn.Click += new System.EventHandler(this.LeftArrow_btn_Click);
            // 
            // RegForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(379, 421);
            this.Controls.Add(this.LeftArrow_btn);
            this.Controls.Add(this.Reg_btn);
            this.Controls.Add(this.Email_txt);
            this.Controls.Add(this.Password_txt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Address_txt);
            this.Controls.Add(this.Phone_txt);
            this.Controls.Add(this.PNumber_txt);
            this.Controls.Add(this.PSerie_txt);
            this.Controls.Add(this.Surname_txt);
            this.Controls.Add(this.LastName_txt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Name_txt);
            this.Controls.Add(this.label1);
            this.Name = "RegForm";
            this.Text = "Регистрация";
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Name_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox LastName_txt;
        private System.Windows.Forms.TextBox Surname_txt;
        private System.Windows.Forms.TextBox PSerie_txt;
        private System.Windows.Forms.TextBox PNumber_txt;
        private System.Windows.Forms.TextBox Phone_txt;
        private System.Windows.Forms.TextBox Address_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox Email_txt;
        private System.Windows.Forms.Button Reg_btn;
        private System.Windows.Forms.PictureBox LeftArrow_btn;
    }
}