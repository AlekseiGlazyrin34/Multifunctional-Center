﻿
namespace Multifunctional_Center
{
    partial class Zapis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zapis));
            this.label1 = new System.Windows.Forms.Label();
            this.multifunctional_CenterDataSet = new Multifunctional_Center.Multifunctional_CenterDataSet();
            this.servicesListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.services_ListTableAdapter = new Multifunctional_Center.Multifunctional_CenterDataSetTableAdapters.Services_ListTableAdapter();
            this.multifunctional_CenterDataSet1 = new Multifunctional_Center.Multifunctional_CenterDataSet1();
            this.servicesListBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.services_ListTableAdapter1 = new Multifunctional_Center.Multifunctional_CenterDataSet1TableAdapters.Services_ListTableAdapter();
            this.ServicesBox = new System.Windows.Forms.ComboBox();
            this.servicesListBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.multifunctional_CenterDataSet3 = new Multifunctional_Center.Multifunctional_CenterDataSet3();
            this.servicesListBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.multifunctional_CenterDataSet2 = new Multifunctional_Center.Multifunctional_CenterDataSet2();
            this.Zapis_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.services_ListTableAdapter2 = new Multifunctional_Center.Multifunctional_CenterDataSet2TableAdapters.Services_ListTableAdapter();
            this.services_ListTableAdapter3 = new Multifunctional_Center.Multifunctional_CenterDataSet3TableAdapters.Services_ListTableAdapter();
            this.LeftArrow_btn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(209, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Выберите услугу";
            // 
            // multifunctional_CenterDataSet
            // 
            this.multifunctional_CenterDataSet.DataSetName = "Multifunctional_CenterDataSet";
            this.multifunctional_CenterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // servicesListBindingSource
            // 
            this.servicesListBindingSource.DataMember = "Services List";
            this.servicesListBindingSource.DataSource = this.multifunctional_CenterDataSet;
            // 
            // services_ListTableAdapter
            // 
            this.services_ListTableAdapter.ClearBeforeFill = true;
            // 
            // multifunctional_CenterDataSet1
            // 
            this.multifunctional_CenterDataSet1.DataSetName = "Multifunctional_CenterDataSet1";
            this.multifunctional_CenterDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // servicesListBindingSource1
            // 
            this.servicesListBindingSource1.DataMember = "Services List";
            this.servicesListBindingSource1.DataSource = this.multifunctional_CenterDataSet1;
            // 
            // services_ListTableAdapter1
            // 
            this.services_ListTableAdapter1.ClearBeforeFill = true;
            // 
            // ServicesBox
            // 
            this.ServicesBox.DataSource = this.servicesListBindingSource3;
            this.ServicesBox.DisplayMember = "Service_Name";
            this.ServicesBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ServicesBox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ServicesBox.FormattingEnabled = true;
            this.ServicesBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ServicesBox.Location = new System.Drawing.Point(45, 123);
            this.ServicesBox.Name = "ServicesBox";
            this.ServicesBox.Size = new System.Drawing.Size(503, 27);
            this.ServicesBox.TabIndex = 2;
            this.ServicesBox.ValueMember = "Service_Name";
            // 
            // servicesListBindingSource3
            // 
            this.servicesListBindingSource3.DataMember = "Services List";
            this.servicesListBindingSource3.DataSource = this.multifunctional_CenterDataSet3;
            // 
            // multifunctional_CenterDataSet3
            // 
            this.multifunctional_CenterDataSet3.DataSetName = "Multifunctional_CenterDataSet3";
            this.multifunctional_CenterDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // servicesListBindingSource2
            // 
            this.servicesListBindingSource2.DataMember = "Services List";
            this.servicesListBindingSource2.DataSource = this.multifunctional_CenterDataSet2;
            // 
            // multifunctional_CenterDataSet2
            // 
            this.multifunctional_CenterDataSet2.DataSetName = "Multifunctional_CenterDataSet2";
            this.multifunctional_CenterDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Zapis_btn
            // 
            this.Zapis_btn.BackColor = System.Drawing.Color.Tomato;
            this.Zapis_btn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zapis_btn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Zapis_btn.Location = new System.Drawing.Point(179, 260);
            this.Zapis_btn.Name = "Zapis_btn";
            this.Zapis_btn.Size = new System.Drawing.Size(230, 77);
            this.Zapis_btn.TabIndex = 3;
            this.Zapis_btn.Text = "Отправить запрос на прием";
            this.Zapis_btn.UseVisualStyleBackColor = false;
            this.Zapis_btn.Click += new System.EventHandler(this.Zapis_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(141, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(301, 54);
            this.label2.TabIndex = 4;
            this.label2.Text = "После того, как вы нажмете на\r\n \"Отправить запрос на прием\" \r\nвам позвонят для ут" +
    "очнения времени приема";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // services_ListTableAdapter2
            // 
            this.services_ListTableAdapter2.ClearBeforeFill = true;
            // 
            // services_ListTableAdapter3
            // 
            this.services_ListTableAdapter3.ClearBeforeFill = true;
            // 
            // LeftArrow_btn
            // 
            this.LeftArrow_btn.Image = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.Image")));
            this.LeftArrow_btn.InitialImage = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.InitialImage")));
            this.LeftArrow_btn.Location = new System.Drawing.Point(2, 3);
            this.LeftArrow_btn.Name = "LeftArrow_btn";
            this.LeftArrow_btn.Size = new System.Drawing.Size(22, 22);
            this.LeftArrow_btn.TabIndex = 13;
            this.LeftArrow_btn.TabStop = false;
            this.LeftArrow_btn.Click += new System.EventHandler(this.LeftArrow_btn_Click);
            // 
            // Zapis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(602, 457);
            this.Controls.Add(this.LeftArrow_btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Zapis_btn);
            this.Controls.Add(this.ServicesBox);
            this.Controls.Add(this.label1);
            this.Name = "Zapis";
            this.Text = "Запись на прием";
            this.Load += new System.EventHandler(this.Zapis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesListBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private Multifunctional_CenterDataSet multifunctional_CenterDataSet;
        private System.Windows.Forms.BindingSource servicesListBindingSource;
        private Multifunctional_CenterDataSetTableAdapters.Services_ListTableAdapter services_ListTableAdapter;
        private Multifunctional_CenterDataSet1 multifunctional_CenterDataSet1;
        private System.Windows.Forms.BindingSource servicesListBindingSource1;
        private Multifunctional_CenterDataSet1TableAdapters.Services_ListTableAdapter services_ListTableAdapter1;
        private System.Windows.Forms.ComboBox ServicesBox;
        private System.Windows.Forms.Button Zapis_btn;
        private System.Windows.Forms.Label label2;
        private Multifunctional_CenterDataSet2 multifunctional_CenterDataSet2;
        private System.Windows.Forms.BindingSource servicesListBindingSource2;
        private Multifunctional_CenterDataSet2TableAdapters.Services_ListTableAdapter services_ListTableAdapter2;
        private Multifunctional_CenterDataSet3 multifunctional_CenterDataSet3;
        private System.Windows.Forms.BindingSource servicesListBindingSource3;
        private Multifunctional_CenterDataSet3TableAdapters.Services_ListTableAdapter services_ListTableAdapter3;
        private System.Windows.Forms.PictureBox LeftArrow_btn;
    }
}