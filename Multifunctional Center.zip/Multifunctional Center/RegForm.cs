﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Multifunctional_Center
{
    
    public partial class RegForm : System.Windows.Forms.Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-H07OG6B; Initial Catalog=Multifunctional Center; Integrated Security=True");
        public RegForm()
        {
            InitializeComponent();
            OnLoad();
        }

        private void OnLoad()
        {
            PSerie_txt.MaxLength = 4;
            PNumber_txt.MaxLength = 6;
            Phone_txt.MaxLength = 15;
        }
        private void Reg_btn_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("INSERT INTO [Registered users] (Passport_Serie, Passport_Number, First_Name, Last_Name,Surname,Email,Password,Phone_Number,Address,Access) " +
                "VALUES('" + PSerie_txt.Text + " ',' " + PNumber_txt.Text + "' , '" + Name_txt.Text + "' , '" + LastName_txt.Text + " ', '" + Surname_txt.Text + " ', '" + Email_txt.Text + " ', '" + Password_txt.Text + " ', '" + Phone_txt.Text + " ', '" + Address_txt.Text + " ','0')", connection);
            connection.Open();
            command.ExecuteNonQuery();
            MessageBox.Show("Вы зарегистрировались");
            this.Hide();
            MainForm MainForm = new MainForm();
            MainForm.Show();
        }

        private void LastName_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {

                e.Handled = true;
            }
            else return;


        }

        private void Name_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {

                e.Handled = true;
            }
            else return;
        }

        private void Surname_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {

                e.Handled = true;
            }
            else return;

        }

        private void Phone_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == '+'))
            {

                 return;
            }
            else e.Handled = true;
        }

        private void PSerie_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {

                return;
            }
            else e.Handled = true; 
        }

        private void LeftArrow_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainf = new MainForm();
            mainf.Show();
        }
    }
}
