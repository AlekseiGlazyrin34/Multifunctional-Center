﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Multifunctional_Center
{
   
    public partial class Zapis : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-H07OG6B; Initial Catalog=Multifunctional Center; Integrated Security=True");
        public Zapis()
        {
            InitializeComponent();
        }

        

        private void Zapis_btn_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("INSERT INTO [Appointment List] (UserPassportSerie, UserPassportNumber, Service_Provided) " +
               "VALUES('" + User.PassportSerie + " ',' " + User.PassportNumber + "' , '" + ServicesBox.SelectedIndex + "')", connection);
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Заявка подана");
        }

        private void Zapis_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "multifunctional_CenterDataSet3.Services_List". При необходимости она может быть перемещена или удалена.
            this.services_ListTableAdapter3.Fill(this.multifunctional_CenterDataSet3.Services_List);

        }

        private void LeftArrow_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MFC Mfc = new MFC();
            Mfc.Show();
        }
    }
}
