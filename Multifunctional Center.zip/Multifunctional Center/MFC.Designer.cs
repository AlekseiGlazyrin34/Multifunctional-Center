﻿
namespace Multifunctional_Center
{
    partial class MFC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Zapis_btn = new System.Windows.Forms.Button();
            this.MFCAdmin_btn = new System.Windows.Forms.Button();
            this.Kab_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Zapis_btn
            // 
            this.Zapis_btn.BackColor = System.Drawing.Color.Tomato;
            this.Zapis_btn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zapis_btn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Zapis_btn.Location = new System.Drawing.Point(212, 107);
            this.Zapis_btn.Name = "Zapis_btn";
            this.Zapis_btn.Size = new System.Drawing.Size(237, 77);
            this.Zapis_btn.TabIndex = 0;
            this.Zapis_btn.Text = "Записаться на прием";
            this.Zapis_btn.UseVisualStyleBackColor = false;
            this.Zapis_btn.Click += new System.EventHandler(this.Zapis_btn_Click);
            // 
            // MFCAdmin_btn
            // 
            this.MFCAdmin_btn.BackColor = System.Drawing.Color.Tomato;
            this.MFCAdmin_btn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MFCAdmin_btn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MFCAdmin_btn.Location = new System.Drawing.Point(212, 200);
            this.MFCAdmin_btn.Name = "MFCAdmin_btn";
            this.MFCAdmin_btn.Size = new System.Drawing.Size(237, 77);
            this.MFCAdmin_btn.TabIndex = 2;
            this.MFCAdmin_btn.Text = "Администрирование МФЦ";
            this.MFCAdmin_btn.UseVisualStyleBackColor = false;
            this.MFCAdmin_btn.Visible = false;
            this.MFCAdmin_btn.Click += new System.EventHandler(this.MFCAdmin_btn_Click);
            // 
            // Kab_lbl
            // 
            this.Kab_lbl.AutoSize = true;
            this.Kab_lbl.BackColor = System.Drawing.Color.Tomato;
            this.Kab_lbl.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Kab_lbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Kab_lbl.Location = new System.Drawing.Point(557, 9);
            this.Kab_lbl.Name = "Kab_lbl";
            this.Kab_lbl.Size = new System.Drawing.Size(99, 15);
            this.Kab_lbl.TabIndex = 3;
            this.Kab_lbl.Text = "Личный кабинет";
            this.Kab_lbl.Click += new System.EventHandler(this.Kab_lbl_Click);
            // 
            // MFC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(666, 335);
            this.Controls.Add(this.Kab_lbl);
            this.Controls.Add(this.MFCAdmin_btn);
            this.Controls.Add(this.Zapis_btn);
            this.Name = "MFC";
            this.Text = "Главная";
            this.Load += new System.EventHandler(this.MFC_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Zapis_btn;
        private System.Windows.Forms.Button MFCAdmin_btn;
        private System.Windows.Forms.Label Kab_lbl;
    }
}