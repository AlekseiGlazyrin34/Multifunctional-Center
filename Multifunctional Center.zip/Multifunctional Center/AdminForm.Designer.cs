﻿
namespace Multifunctional_Center
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Users = new System.Windows.Forms.TabPage();
            this.Clear_btn = new System.Windows.Forms.Button();
            this.Delete_btn = new System.Windows.Forms.Button();
            this.Update_btn = new System.Windows.Forms.Button();
            this.Save_btn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Access = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.PhoneNumber = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Surname = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.PassNumber = new System.Windows.Forms.TextBox();
            this.PassSerie = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Appointments = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.A_Time = new System.Windows.Forms.TextBox();
            this.A_Date = new System.Windows.Forms.TextBox();
            this.Service_Provided = new System.Windows.Forms.TextBox();
            this.Employee_Id = new System.Windows.Forms.TextBox();
            this.UserPassportNumber = new System.Windows.Forms.TextBox();
            this.UserPassportSerie = new System.Windows.Forms.TextBox();
            this.Appointment_Id = new System.Windows.Forms.TextBox();
            this.Clear_btn2 = new System.Windows.Forms.Button();
            this.Delete_btn2 = new System.Windows.Forms.Button();
            this.Update_btn2 = new System.Windows.Forms.Button();
            this.Save_btn2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Employees = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Centers = new System.Windows.Forms.TabPage();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.Jobs = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.Services = new System.Windows.Forms.TabPage();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.registeredUsersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.multifunctional_CenterDataSet5 = new Multifunctional_Center.Multifunctional_CenterDataSet5();
            this.registered_usersTableAdapter = new Multifunctional_Center.Multifunctional_CenterDataSet5TableAdapters.Registered_usersTableAdapter();
            this.LeftArrow_btn = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.Users.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Appointments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.Employees.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.Centers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.Jobs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.Services.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registeredUsersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Users);
            this.tabControl1.Controls.Add(this.Appointments);
            this.tabControl1.Controls.Add(this.Employees);
            this.tabControl1.Controls.Add(this.Centers);
            this.tabControl1.Controls.Add(this.Jobs);
            this.tabControl1.Controls.Add(this.Services);
            this.tabControl1.Location = new System.Drawing.Point(2, 30);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1230, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // Users
            // 
            this.Users.Controls.Add(this.Clear_btn);
            this.Users.Controls.Add(this.Delete_btn);
            this.Users.Controls.Add(this.Update_btn);
            this.Users.Controls.Add(this.Save_btn);
            this.Users.Controls.Add(this.label10);
            this.Users.Controls.Add(this.label9);
            this.Users.Controls.Add(this.label8);
            this.Users.Controls.Add(this.label7);
            this.Users.Controls.Add(this.label6);
            this.Users.Controls.Add(this.label5);
            this.Users.Controls.Add(this.label4);
            this.Users.Controls.Add(this.label3);
            this.Users.Controls.Add(this.label2);
            this.Users.Controls.Add(this.label1);
            this.Users.Controls.Add(this.Access);
            this.Users.Controls.Add(this.Address);
            this.Users.Controls.Add(this.PhoneNumber);
            this.Users.Controls.Add(this.Password);
            this.Users.Controls.Add(this.Email);
            this.Users.Controls.Add(this.Surname);
            this.Users.Controls.Add(this.LastName);
            this.Users.Controls.Add(this.FirstName);
            this.Users.Controls.Add(this.PassNumber);
            this.Users.Controls.Add(this.PassSerie);
            this.Users.Controls.Add(this.dataGridView1);
            this.Users.Location = new System.Drawing.Point(4, 22);
            this.Users.Name = "Users";
            this.Users.Padding = new System.Windows.Forms.Padding(3);
            this.Users.Size = new System.Drawing.Size(1222, 506);
            this.Users.TabIndex = 0;
            this.Users.Text = "Зарегистрированные пользователи";
            this.Users.UseVisualStyleBackColor = true;
            // 
            // Clear_btn
            // 
            this.Clear_btn.BackColor = System.Drawing.Color.Tomato;
            this.Clear_btn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Clear_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Clear_btn.Location = new System.Drawing.Point(1059, 297);
            this.Clear_btn.Name = "Clear_btn";
            this.Clear_btn.Size = new System.Drawing.Size(109, 50);
            this.Clear_btn.TabIndex = 24;
            this.Clear_btn.Text = "Стереть";
            this.Clear_btn.UseVisualStyleBackColor = false;
            this.Clear_btn.Click += new System.EventHandler(this.Clear_btn_Click);
            // 
            // Delete_btn
            // 
            this.Delete_btn.BackColor = System.Drawing.Color.Tomato;
            this.Delete_btn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Delete_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Delete_btn.Location = new System.Drawing.Point(1059, 222);
            this.Delete_btn.Name = "Delete_btn";
            this.Delete_btn.Size = new System.Drawing.Size(109, 50);
            this.Delete_btn.TabIndex = 23;
            this.Delete_btn.Text = "Удалить";
            this.Delete_btn.UseVisualStyleBackColor = false;
            this.Delete_btn.Click += new System.EventHandler(this.Delete_btn_Click);
            // 
            // Update_btn
            // 
            this.Update_btn.BackColor = System.Drawing.Color.Tomato;
            this.Update_btn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Update_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Update_btn.Location = new System.Drawing.Point(1059, 147);
            this.Update_btn.Name = "Update_btn";
            this.Update_btn.Size = new System.Drawing.Size(109, 50);
            this.Update_btn.TabIndex = 22;
            this.Update_btn.Text = "Обновить";
            this.Update_btn.UseVisualStyleBackColor = false;
            this.Update_btn.Click += new System.EventHandler(this.Update_btn_Click);
            // 
            // Save_btn
            // 
            this.Save_btn.BackColor = System.Drawing.Color.Tomato;
            this.Save_btn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Save_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Save_btn.Location = new System.Drawing.Point(1059, 72);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(109, 50);
            this.Save_btn.TabIndex = 21;
            this.Save_btn.Text = "Сохранить";
            this.Save_btn.UseVisualStyleBackColor = false;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(975, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 15);
            this.label10.TabIndex = 20;
            this.label10.Text = "Доступ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(872, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 15);
            this.label9.TabIndex = 19;
            this.label9.Text = "Адрес";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(741, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "Номер телефона";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(668, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "Пароль";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(537, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "Электронная почта";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(462, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "Отчество";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(361, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "Фамилия";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(276, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 15);
            this.label3.TabIndex = 13;
            this.label3.Text = "Имя";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(144, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 15);
            this.label2.TabIndex = 12;
            this.label2.Text = "Номер паспорта";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(39, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "Серия пасспорта";
            // 
            // Access
            // 
            this.Access.Location = new System.Drawing.Point(941, 46);
            this.Access.Name = "Access";
            this.Access.Size = new System.Drawing.Size(102, 20);
            this.Access.TabIndex = 10;
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(839, 46);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(104, 20);
            this.Address.TabIndex = 9;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.Location = new System.Drawing.Point(741, 46);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.PhoneNumber.TabIndex = 8;
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(640, 46);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(102, 20);
            this.Password.TabIndex = 7;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(540, 46);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(102, 20);
            this.Email.TabIndex = 6;
            // 
            // Surname
            // 
            this.Surname.Location = new System.Drawing.Point(440, 46);
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(102, 20);
            this.Surname.TabIndex = 5;
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(341, 46);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(101, 20);
            this.LastName.TabIndex = 4;
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(242, 46);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(100, 20);
            this.FirstName.TabIndex = 3;
            // 
            // PassNumber
            // 
            this.PassNumber.Location = new System.Drawing.Point(141, 46);
            this.PassNumber.Name = "PassNumber";
            this.PassNumber.Size = new System.Drawing.Size(103, 20);
            this.PassNumber.TabIndex = 2;
            // 
            // PassSerie
            // 
            this.PassSerie.Location = new System.Drawing.Point(41, 46);
            this.PassSerie.Name = "PassSerie";
            this.PassSerie.Size = new System.Drawing.Size(100, 20);
            this.PassSerie.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 72);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1043, 352);
            this.dataGridView1.TabIndex = 0;
            // 
            // Appointments
            // 
            this.Appointments.Controls.Add(this.label18);
            this.Appointments.Controls.Add(this.label11);
            this.Appointments.Controls.Add(this.label12);
            this.Appointments.Controls.Add(this.label13);
            this.Appointments.Controls.Add(this.label14);
            this.Appointments.Controls.Add(this.label16);
            this.Appointments.Controls.Add(this.label17);
            this.Appointments.Controls.Add(this.A_Time);
            this.Appointments.Controls.Add(this.A_Date);
            this.Appointments.Controls.Add(this.Service_Provided);
            this.Appointments.Controls.Add(this.Employee_Id);
            this.Appointments.Controls.Add(this.UserPassportNumber);
            this.Appointments.Controls.Add(this.UserPassportSerie);
            this.Appointments.Controls.Add(this.Appointment_Id);
            this.Appointments.Controls.Add(this.Clear_btn2);
            this.Appointments.Controls.Add(this.Delete_btn2);
            this.Appointments.Controls.Add(this.Update_btn2);
            this.Appointments.Controls.Add(this.Save_btn2);
            this.Appointments.Controls.Add(this.dataGridView2);
            this.Appointments.Location = new System.Drawing.Point(4, 22);
            this.Appointments.Name = "Appointments";
            this.Appointments.Padding = new System.Windows.Forms.Padding(3);
            this.Appointments.Size = new System.Drawing.Size(1221, 506);
            this.Appointments.TabIndex = 1;
            this.Appointments.Text = "Записи на прием";
            this.Appointments.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(245, 29);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 15);
            this.label18.TabIndex = 43;
            this.label18.Text = "Номер паспорта";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(668, 29);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 15);
            this.label11.TabIndex = 42;
            this.label11.Text = "Время";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(571, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 15);
            this.label12.TabIndex = 41;
            this.label12.Text = "Дата";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(461, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 15);
            this.label13.TabIndex = 40;
            this.label13.Text = "Услуга";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(360, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 15);
            this.label14.TabIndex = 39;
            this.label14.Text = "Сотрудник";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(143, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 15);
            this.label16.TabIndex = 37;
            this.label16.Text = "Серия паспорта";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(50, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 15);
            this.label17.TabIndex = 36;
            this.label17.Text = "Номер записи";
            // 
            // A_Time
            // 
            this.A_Time.Location = new System.Drawing.Point(639, 47);
            this.A_Time.Name = "A_Time";
            this.A_Time.Size = new System.Drawing.Size(102, 20);
            this.A_Time.TabIndex = 35;
            // 
            // A_Date
            // 
            this.A_Date.Location = new System.Drawing.Point(539, 47);
            this.A_Date.Name = "A_Date";
            this.A_Date.Size = new System.Drawing.Size(102, 20);
            this.A_Date.TabIndex = 34;
            // 
            // Service_Provided
            // 
            this.Service_Provided.Location = new System.Drawing.Point(439, 47);
            this.Service_Provided.Name = "Service_Provided";
            this.Service_Provided.Size = new System.Drawing.Size(102, 20);
            this.Service_Provided.TabIndex = 33;
            // 
            // Employee_Id
            // 
            this.Employee_Id.Location = new System.Drawing.Point(340, 47);
            this.Employee_Id.Name = "Employee_Id";
            this.Employee_Id.Size = new System.Drawing.Size(101, 20);
            this.Employee_Id.TabIndex = 32;
            // 
            // UserPassportNumber
            // 
            this.UserPassportNumber.Location = new System.Drawing.Point(241, 47);
            this.UserPassportNumber.Name = "UserPassportNumber";
            this.UserPassportNumber.Size = new System.Drawing.Size(100, 20);
            this.UserPassportNumber.TabIndex = 31;
            // 
            // UserPassportSerie
            // 
            this.UserPassportSerie.Location = new System.Drawing.Point(140, 47);
            this.UserPassportSerie.Name = "UserPassportSerie";
            this.UserPassportSerie.Size = new System.Drawing.Size(103, 20);
            this.UserPassportSerie.TabIndex = 30;
            // 
            // Appointment_Id
            // 
            this.Appointment_Id.Location = new System.Drawing.Point(40, 47);
            this.Appointment_Id.Name = "Appointment_Id";
            this.Appointment_Id.Size = new System.Drawing.Size(100, 20);
            this.Appointment_Id.TabIndex = 29;
            // 
            // Clear_btn2
            // 
            this.Clear_btn2.BackColor = System.Drawing.Color.Tomato;
            this.Clear_btn2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Clear_btn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Clear_btn2.Location = new System.Drawing.Point(1049, 298);
            this.Clear_btn2.Name = "Clear_btn2";
            this.Clear_btn2.Size = new System.Drawing.Size(109, 50);
            this.Clear_btn2.TabIndex = 28;
            this.Clear_btn2.Text = "Стереть";
            this.Clear_btn2.UseVisualStyleBackColor = false;
            this.Clear_btn2.Click += new System.EventHandler(this.Clear_btn2_Click);
            // 
            // Delete_btn2
            // 
            this.Delete_btn2.BackColor = System.Drawing.Color.Tomato;
            this.Delete_btn2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Delete_btn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Delete_btn2.Location = new System.Drawing.Point(1049, 223);
            this.Delete_btn2.Name = "Delete_btn2";
            this.Delete_btn2.Size = new System.Drawing.Size(109, 50);
            this.Delete_btn2.TabIndex = 27;
            this.Delete_btn2.Text = "Удалить";
            this.Delete_btn2.UseVisualStyleBackColor = false;
            this.Delete_btn2.Click += new System.EventHandler(this.Delete_btn2_Click);
            // 
            // Update_btn2
            // 
            this.Update_btn2.BackColor = System.Drawing.Color.Tomato;
            this.Update_btn2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Update_btn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Update_btn2.Location = new System.Drawing.Point(1049, 148);
            this.Update_btn2.Name = "Update_btn2";
            this.Update_btn2.Size = new System.Drawing.Size(109, 50);
            this.Update_btn2.TabIndex = 26;
            this.Update_btn2.Text = "Обновить";
            this.Update_btn2.UseVisualStyleBackColor = false;
            this.Update_btn2.Click += new System.EventHandler(this.Update_btn2_Click);
            // 
            // Save_btn2
            // 
            this.Save_btn2.BackColor = System.Drawing.Color.Tomato;
            this.Save_btn2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Save_btn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Save_btn2.Location = new System.Drawing.Point(1049, 73);
            this.Save_btn2.Name = "Save_btn2";
            this.Save_btn2.Size = new System.Drawing.Size(109, 50);
            this.Save_btn2.TabIndex = 25;
            this.Save_btn2.Text = "Сохранить";
            this.Save_btn2.UseVisualStyleBackColor = false;
            this.Save_btn2.Click += new System.EventHandler(this.Save_btn2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 73);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1030, 351);
            this.dataGridView2.TabIndex = 0;
            // 
            // Employees
            // 
            this.Employees.Controls.Add(this.dataGridView3);
            this.Employees.Location = new System.Drawing.Point(4, 22);
            this.Employees.Name = "Employees";
            this.Employees.Padding = new System.Windows.Forms.Padding(3);
            this.Employees.Size = new System.Drawing.Size(1222, 506);
            this.Employees.TabIndex = 2;
            this.Employees.Text = "Список сотрудников";
            this.Employees.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(0, 77);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(904, 347);
            this.dataGridView3.TabIndex = 0;
            // 
            // Centers
            // 
            this.Centers.Controls.Add(this.dataGridView4);
            this.Centers.Location = new System.Drawing.Point(4, 22);
            this.Centers.Name = "Centers";
            this.Centers.Padding = new System.Windows.Forms.Padding(3);
            this.Centers.Size = new System.Drawing.Size(1222, 506);
            this.Centers.TabIndex = 3;
            this.Centers.Text = "Мультифункциональные центры";
            this.Centers.UseVisualStyleBackColor = true;
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(0, 77);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(904, 347);
            this.dataGridView4.TabIndex = 1;
            // 
            // Jobs
            // 
            this.Jobs.Controls.Add(this.dataGridView5);
            this.Jobs.Location = new System.Drawing.Point(4, 22);
            this.Jobs.Name = "Jobs";
            this.Jobs.Size = new System.Drawing.Size(1222, 506);
            this.Jobs.TabIndex = 4;
            this.Jobs.Text = "Должности";
            this.Jobs.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            this.dataGridView5.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(0, 77);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(904, 347);
            this.dataGridView5.TabIndex = 1;
            // 
            // Services
            // 
            this.Services.Controls.Add(this.dataGridView6);
            this.Services.Location = new System.Drawing.Point(4, 22);
            this.Services.Name = "Services";
            this.Services.Size = new System.Drawing.Size(1222, 424);
            this.Services.TabIndex = 5;
            this.Services.Text = "Услуги";
            this.Services.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(0, 77);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(904, 347);
            this.dataGridView6.TabIndex = 1;
            // 
            // registeredUsersBindingSource
            // 
            this.registeredUsersBindingSource.DataMember = "Registered users";
            this.registeredUsersBindingSource.DataSource = this.multifunctional_CenterDataSet5;
            // 
            // multifunctional_CenterDataSet5
            // 
            this.multifunctional_CenterDataSet5.DataSetName = "Multifunctional_CenterDataSet5";
            this.multifunctional_CenterDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // registered_usersTableAdapter
            // 
            this.registered_usersTableAdapter.ClearBeforeFill = true;
            // 
            // LeftArrow_btn
            // 
            this.LeftArrow_btn.Image = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.Image")));
            this.LeftArrow_btn.InitialImage = ((System.Drawing.Image)(resources.GetObject("LeftArrow_btn.InitialImage")));
            this.LeftArrow_btn.Location = new System.Drawing.Point(6, 2);
            this.LeftArrow_btn.Name = "LeftArrow_btn";
            this.LeftArrow_btn.Size = new System.Drawing.Size(22, 22);
            this.LeftArrow_btn.TabIndex = 14;
            this.LeftArrow_btn.TabStop = false;
            this.LeftArrow_btn.Click += new System.EventHandler(this.LeftArrow_btn_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1229, 480);
            this.Controls.Add(this.LeftArrow_btn);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminForm";
            this.Text = "Администрация МФЦ";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.Users.ResumeLayout(false);
            this.Users.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Appointments.ResumeLayout(false);
            this.Appointments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.Employees.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.Centers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.Jobs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.Services.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registeredUsersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.multifunctional_CenterDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArrow_btn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Users;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage Appointments;
        private System.Windows.Forms.TabPage Employees;
        private System.Windows.Forms.TabPage Centers;
        private System.Windows.Forms.TabPage Jobs;
        private System.Windows.Forms.TabPage Services;
        private Multifunctional_CenterDataSet5 multifunctional_CenterDataSet5;
        private System.Windows.Forms.BindingSource registeredUsersBindingSource;
        private Multifunctional_CenterDataSet5TableAdapters.Registered_usersTableAdapter registered_usersTableAdapter;
        private System.Windows.Forms.TextBox Access;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox PhoneNumber;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox PassNumber;
        private System.Windows.Forms.TextBox PassSerie;
        private System.Windows.Forms.Button Clear_btn;
        private System.Windows.Forms.Button Delete_btn;
        private System.Windows.Forms.Button Update_btn;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox A_Time;
        private System.Windows.Forms.TextBox A_Date;
        private System.Windows.Forms.TextBox Service_Provided;
        private System.Windows.Forms.TextBox Employee_Id;
        private System.Windows.Forms.TextBox UserPassportNumber;
        private System.Windows.Forms.TextBox UserPassportSerie;
        private System.Windows.Forms.TextBox Appointment_Id;
        private System.Windows.Forms.Button Clear_btn2;
        private System.Windows.Forms.Button Delete_btn2;
        private System.Windows.Forms.Button Update_btn2;
        private System.Windows.Forms.Button Save_btn2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.PictureBox LeftArrow_btn;
    }
}